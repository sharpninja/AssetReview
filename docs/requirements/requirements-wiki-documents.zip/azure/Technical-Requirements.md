# Technical Requirements (QBrain.AI)

## TR-ASSETREVIEW-ANIMATION-001

**Index and play combat animation sequences** — Hero and monster combat folders expose storyboard sequences that can play in flight, step a frame, and switch sequence.
**Covered by:** FR: FR-ASSETREVIEW-011; TEST: TEST-COMBATSEQUENCES-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Hero and monster combat folders expose storyboard sequences that can play in flight, step a frame, and switch sequence. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveStoryboard); ./build.ps1 Test)

## TR-ASSETREVIEW-ASSETINDEX-001

**Build and refresh the asset index** — The review app lists PNG and SVG files from the asset root under the configured title. Reload All rescans the asset root and shows files added after launch. When _manifest.md lists assets, the review index uses that list instead of every image in the folder.
**Covered by:** FR: FR-ASSETREVIEW-001, FR-ASSETREVIEW-005, FR-ASSETREVIEW-008; TEST: TEST-ASSETGRID-001, TEST-ASSETRELOAD-001, TEST-MANIFESTPREFERENCE-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The review app lists PNG and SVG files from the asset root under the configured title. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DrivePngAndSvgGrid); ./build.ps1 Test)
- [ ] Reload All rescans the asset root and shows files added after launch. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveReloadAll); ./build.ps1 Test)
- [ ] When _manifest.md lists assets, the review index uses that list instead of every image in the folder. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveManifestPreference); ./build.ps1 Test)

## TR-ASSETREVIEW-CLI-001

**Run the review host through supported CLI modes** — --version prints the asset-review version and exits successfully. --server-only serves the review UI without opening a desktop window and reports the URL and launch mode.
**Covered by:** FR: FR-ASSETREVIEW-012, FR-ASSETREVIEW-013; TEST: TEST-TOOLVERSION-001, TEST-PORTVALIDATION-001, TEST-SERVERONLY-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] --version prints the asset-review version and exits successfully. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveVersion); ./build.ps1 Test)
- [ ] --server-only serves the review UI without opening a desktop window and reports the URL and launch mode. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveServerOnly); ./build.ps1 Test)

## TR-ASSETREVIEW-CLI-002

**Validate port** — A non-integer or out-of-range --port value exits with code 2 and an error on stderr.
**Covered by:** FR: FR-ASSETREVIEW-013; TEST: TEST-PORTVALIDATION-001, TEST-SERVERONLY-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A non-integer or out-of-range --port value exits with code 2 and an error on stderr. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DrivePortValidation); ./build.ps1 Test)

## TR-ASSETREVIEW-FEEDBACK-001

**Persist and present review decisions** — Feedback is appended as JSON Lines recording the asset path, decision, comment, preview context, and a UTC timestamp. Clear Reviews removes non-approved feedback and keeps the current approved decisions. Approve and Request refinement save a decision and show it on the open asset.
**Covered by:** FR: FR-ASSETREVIEW-002, FR-ASSETREVIEW-006, FR-ASSETREVIEW-010; TEST: TEST-FEEDBACKRECORD-001, TEST-CLEARREVIEWS-001, TEST-DECISIONVALIDATION-001, TEST-REVIEWDECISIONS-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Feedback is appended as JSON Lines recording the asset path, decision, comment, preview context, and a UTC timestamp. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveFeedbackRecord); ./build.ps1 Test)
- [ ] Clear Reviews removes non-approved feedback and keeps the current approved decisions. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveClearReviews); ./build.ps1 Test)
- [ ] Approve and Request refinement save a decision and show it on the open asset. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveApproveAndRefine); ./build.ps1 Test)

## TR-ASSETREVIEW-FEEDBACK-002

**Reject unknown decisions** — Feedback decisions other than approved or refinement are rejected.
**Covered by:** FR: FR-ASSETREVIEW-010; TEST: TEST-DECISIONVALIDATION-001, TEST-REVIEWDECISIONS-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Feedback decisions other than approved or refinement are rejected. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveUnknownDecision); ./build.ps1 Test)

## TR-ASSETREVIEW-MANIFEST-001

**Generate an asset review manifest** — --generate-manifest scans the asset root for PNG and SVG files, writes backtick-wrapped relative paths to _manifest.md, and exits.
**Covered by:** FR: FR-ASSETREVIEW-007; TEST: TEST-ASSETEXCLUSIONS-001, TEST-MANIFESTGENERATION-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] --generate-manifest scans the asset root for PNG and SVG files, writes backtick-wrapped relative paths to _manifest.md, and exits. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveGenerateManifest); ./build.ps1 Test)

## TR-ASSETREVIEW-MANIFEST-002

**Skip non-review paths** — Manifest generation and the review index skip non-image files and debug, screenshot, crawl-shot, and test-output paths, while still listing artifacts/art-approval.
**Covered by:** FR: FR-ASSETREVIEW-007; TEST: TEST-ASSETEXCLUSIONS-001, TEST-MANIFESTGENERATION-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Manifest generation and the review index skip non-image files and debug, screenshot, crawl-shot, and test-output paths, while still listing artifacts/art-approval. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveExcludedPaths); ./build.ps1 Test)

## TR-ASSETREVIEW-NAVIGATION-001

**Navigate and filter the review surfaces** — Search text and the All, Open, Approved, and Refine filters limit which assets are shown. The folder rail filters the grid and shows approval, refinement, and total counts. Next, previous, and back navigation move through the current asset list and return to the grid.
**Covered by:** FR: FR-ASSETREVIEW-009, FR-ASSETREVIEW-016, FR-ASSETREVIEW-017; TEST: TEST-ASSETFILTERS-001, TEST-FOLDERRAIL-001, TEST-DETAILNAVIGATION-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Search text and the All, Open, Approved, and Refine filters limit which assets are shown. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveSearchAndFilters); ./build.ps1 Test)
- [ ] The folder rail filters the grid and shows approval, refinement, and total counts. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveFolderRail); ./build.ps1 Test)
- [ ] Next, previous, and back navigation move through the current asset list and return to the grid. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveNavigation); ./build.ps1 Test)

## TR-ASSETREVIEW-PACKAGING-001

**Package and dispatch OS-specific AssetReview applications** — Produce framework-dependent runtime-specific payloads and a portable managed launcher in one .NET tool package.
**Covered by:** FR: FR-ASSETREVIEW-020; TEST: TEST-ASSETREVIEW-003
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The SharpNinja.AssetReview.Tool NuGet package contains a portable asset-review launcher and Windows and Linux application payloads for x64 and ARM64.
- [ ] The launcher selects the payload using the running OS and process architecture, preserves the working directory and arguments, and returns the application exit code.
- [ ] The Nuke packaging target verifies the package layout and target metadata. The same artifact installs and launches the matching payload on both Windows and Linux.

## TR-ASSETREVIEW-PATHS-001

**Enforce asset root boundaries** — Asset and feedback routes reject paths that escape the asset root.
**Covered by:** FR: FR-ASSETREVIEW-014; TEST: TEST-ASSETBOUNDARY-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Asset and feedback routes reject paths that escape the asset root. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DrivePathEscape); ./build.ps1 Test)

## TR-ASSETREVIEW-PREVIEW-001

**Present and control the asset preview** — The detail view previews an asset on a selectable C64 palette background. Zoom changes through the slider or Ctrl/Meta+mouse wheel, and a plain wheel scrolls the preview when the image overflows. The page applies light and dark themes from the theme query and from assetReviewSetTheme, which the embedded host calls.
**Covered by:** FR: FR-ASSETREVIEW-003, FR-ASSETREVIEW-004, FR-ASSETREVIEW-015; TEST: TEST-PREVIEWPALETTE-001, TEST-PREVIEWZOOM-001, TEST-REVIEWTHEMES-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The detail view previews an asset on a selectable C64 palette background. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveC64Palette); ./build.ps1 Test)
- [ ] Zoom changes through the slider or Ctrl/Meta+mouse wheel, and a plain wheel scrolls the preview when the image overflows. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveZoomAndScroll); ./build.ps1 Test)
- [ ] The page applies light and dark themes from the theme query and from assetReviewSetTheme, which the embedded host calls. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveTheme); ./build.ps1 Test)

## TR-ASSETREVIEW-STORYBOARD-001

**Validate and preserve the storyboard transition graph** — Parse manifest transitions from explicit frame IDs, resolve destinations per sequence, validate forward paths and loop edges, and preserve authored graph definitions across manifest regeneration.
**Covered by:** FR: FR-ASSETREVIEW-018; TEST: TEST-ASSETREVIEW-001
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A storyboard manifest can assign frame IDs and author labeled branches and loops. Loading returns each frame and transition with its original label and explicit target, including shared destinations and repeated references to the same asset.
- [ ] Regenerating a manifest preserves the authored storyboard graph, and legacy ordered storyboards still load with their original frame order.
- [ ] An invalid graph reports the relevant manifest and source line. Rejected graph data and missing frame files do not prevent valid storyboards in the same manifest from loading.

## TR-ASSETREVIEW-STORYBOARD-002

**Render and navigate authored storyboard activity diagrams** — Generate a PlantUML activity diagram from the validated manifest graph, render it locally, and use authored transitions for review navigation.
**Covered by:** FR: FR-ASSETREVIEW-019; TEST: TEST-ASSETREVIEW-002
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The storyboard displays a locally rendered PlantUML activity diagram showing each authored frame occurrence, labeled branch, shared destination, and labeled loop.
- [ ] Reviewers can select transitions, revisit prior frames, and attach feedback to the actual frame occurrence while existing linear storyboard behavior remains available.
- [ ] An invalid manifest or unavailable local renderer is explained in the review UI, which remains usable for reviewing available frames.

## TR-ASSETREVIEW-STORYBOARD-003

**Connect storyboard navigation to the wireframe previewer** — Use the existing graph transitions for named branch choices, loop repetition and exits, and keep the wireframe and visited frame synchronized.
**Covered by:** FR: FR-ASSETREVIEW-021; TEST: TEST-ASSETREVIEW-004
**Status:** pending
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The simulator displays the actual wireframe in the existing previewer at each visited step and provides navigation icons to move forward, revisit the previous step, or restart.
- [ ] Every outgoing branch is available as a button showing its authored label. Selecting it previews the branch destination.
- [ ] A loop can repeat via its authored label or leave via Break. Break follows an authored Next exit or presents authored branch exits. If there is no exit, the simulation ends on the final wireframe of the loop.

