# Testing Requirements (QBrain.AI)

## TEST-ASSETBOUNDARY

### TEST-ASSETBOUNDARY-001

Asset and feedback routes reject paths that escape the asset root. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Asset and feedback routes reject paths that escape the asset root. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DrivePathEscape); ./build.ps1 Test)


## TEST-ASSETEXCLUSIONS

### TEST-ASSETEXCLUSIONS-001

Manifest generation and the review index skip non-image files and debug, screenshot, crawl-shot, and test-output paths, while still listing artifacts/art-approval. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Manifest generation and the review index skip non-image files and debug, screenshot, crawl-shot, and test-output paths, while still listing artifacts/art-approval. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveExcludedPaths); ./build.ps1 Test)


## TEST-ASSETFILTERS

### TEST-ASSETFILTERS-001

Search text and the All, Open, Approved, and Refine filters limit which assets are shown. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Search text and the All, Open, Approved, and Refine filters limit which assets are shown. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveSearchAndFilters); ./build.ps1 Test)


## TEST-ASSETGRID

### TEST-ASSETGRID-001

The review app lists PNG and SVG files from the asset root under the configured title. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] The review app lists PNG and SVG files from the asset root under the configured title. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DrivePngAndSvgGrid); ./build.ps1 Test)


## TEST-ASSETRELOAD

### TEST-ASSETRELOAD-001

Reload All rescans the asset root and shows files added after launch. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Reload All rescans the asset root and shows files added after launch. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveReloadAll); ./build.ps1 Test)


## TEST-ASSETREVIEW

### TEST-ASSETREVIEW-001

Start AssetReview against controlled fixtures and verify the loaded graph, legacy frame order, preservation across regeneration, and diagnostics for malformed or unresolved graph references.

**Acceptance Criteria:**
- [ ] A storyboard manifest can assign frame IDs and author labeled branches and loops. Loading returns each frame and transition with its original label and explicit target, including shared destinations and repeated references to the same asset.
- [ ] Regenerating a manifest preserves the authored storyboard graph, and legacy ordered storyboards still load with their original frame order.
- [ ] An invalid graph reports the relevant manifest and source line. Rejected graph data and missing frame files do not prevent valid storyboards in the same manifest from loading.

### TEST-ASSETREVIEW-002

Verify diagram labels and topology with real PlantUML, navigate a branch and loop in the review UI, and verify fallback for rendering errors and invalid manifests.

**Acceptance Criteria:**
- [ ] The storyboard displays a locally rendered PlantUML activity diagram showing each authored frame occurrence, labeled branch, shared destination, and labeled loop.
- [ ] Reviewers can select transitions, revisit prior frames, and attach feedback to the actual frame occurrence while existing linear storyboard behavior remains available.
- [ ] An invalid manifest or unavailable local renderer is explained in the review UI, which remains usable for reviewing available frames.

### TEST-ASSETREVIEW-003

Inspect the Nuke package and exercise host selection, argument forwarding, working directory, and exit status on Windows and Linux.

**Acceptance Criteria:**
- [ ] The SharpNinja.AssetReview.Tool NuGet package contains a portable asset-review launcher and Windows and Linux application payloads for x64 and ARM64.
- [ ] The launcher selects the payload using the running OS and process architecture, preserves the working directory and arguments, and returns the application exit code.
- [ ] The Nuke packaging target verifies the package layout and target metadata. The same artifact installs and launches the matching payload on both Windows and Linux.

### TEST-ASSETREVIEW-004

Exercise navigation icons, labeled choices, repeat and Break, and assert which wireframe image the browser displays on each visit.

**Acceptance Criteria:**
- [ ] The simulator displays the actual wireframe in the existing previewer at each visited step and provides navigation icons to move forward, revisit the previous step, or restart.
- [ ] Every outgoing branch is available as a button showing its authored label. Selecting it previews the branch destination.
- [ ] A loop can repeat via its authored label or leave via Break. Break follows an authored Next exit or presents authored branch exits. If there is no exit, the simulation ends on the final wireframe of the loop.


## TEST-CLEARREVIEWS

### TEST-CLEARREVIEWS-001

Clear Reviews removes non-approved feedback and keeps the current approved decisions. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Clear Reviews removes non-approved feedback and keeps the current approved decisions. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveClearReviews); ./build.ps1 Test)


## TEST-COMBATSEQUENCES

### TEST-COMBATSEQUENCES-001

Hero and monster combat folders expose storyboard sequences that can play in flight, step a frame, and switch sequence. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Hero and monster combat folders expose storyboard sequences that can play in flight, step a frame, and switch sequence. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveStoryboard); ./build.ps1 Test)


## TEST-DECISIONVALIDATION

### TEST-DECISIONVALIDATION-001

Feedback decisions other than approved or refinement are rejected. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Feedback decisions other than approved or refinement are rejected. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveUnknownDecision); ./build.ps1 Test)


## TEST-DETAILNAVIGATION

### TEST-DETAILNAVIGATION-001

Next, previous, and back navigation move through the current asset list and return to the grid. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Next, previous, and back navigation move through the current asset list and return to the grid. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveNavigation); ./build.ps1 Test)


## TEST-FEEDBACKRECORD

### TEST-FEEDBACKRECORD-001

Feedback is appended as JSON Lines recording the asset path, decision, comment, preview context, and a UTC timestamp. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Feedback is appended as JSON Lines recording the asset path, decision, comment, preview context, and a UTC timestamp. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveFeedbackRecord); ./build.ps1 Test)


## TEST-FOLDERRAIL

### TEST-FOLDERRAIL-001

The folder rail filters the grid and shows approval, refinement, and total counts. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] The folder rail filters the grid and shows approval, refinement, and total counts. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveFolderRail); ./build.ps1 Test)


## TEST-MANIFESTGENERATION

### TEST-MANIFESTGENERATION-001

--generate-manifest scans the asset root for PNG and SVG files, writes backtick-wrapped relative paths to _manifest.md, and exits. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] --generate-manifest scans the asset root for PNG and SVG files, writes backtick-wrapped relative paths to _manifest.md, and exits. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveGenerateManifest); ./build.ps1 Test)


## TEST-MANIFESTPREFERENCE

### TEST-MANIFESTPREFERENCE-001

When _manifest.md lists assets, the review index uses that list instead of every image in the folder. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] When _manifest.md lists assets, the review index uses that list instead of every image in the folder. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveManifestPreference); ./build.ps1 Test)


## TEST-PORTVALIDATION

### TEST-PORTVALIDATION-001

A non-integer or out-of-range --port value exits with code 2 and an error on stderr. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] A non-integer or out-of-range --port value exits with code 2 and an error on stderr. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DrivePortValidation); ./build.ps1 Test)


## TEST-PREVIEWPALETTE

### TEST-PREVIEWPALETTE-001

The detail view previews an asset on a selectable C64 palette background. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] The detail view previews an asset on a selectable C64 palette background. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveC64Palette); ./build.ps1 Test)


## TEST-PREVIEWZOOM

### TEST-PREVIEWZOOM-001

Zoom changes through the slider or Ctrl/Meta+mouse wheel, and a plain wheel scrolls the preview when the image overflows. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Zoom changes through the slider or Ctrl/Meta+mouse wheel, and a plain wheel scrolls the preview when the image overflows. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveZoomAndScroll); ./build.ps1 Test)


## TEST-REVIEWDECISIONS

### TEST-REVIEWDECISIONS-001

Approve and Request refinement save a decision and show it on the open asset. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] Approve and Request refinement save a decision and show it on the open asset. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveApproveAndRefine); ./build.ps1 Test)


## TEST-REVIEWTHEMES

### TEST-REVIEWTHEMES-001

The page applies light and dark themes from the theme query and from assetReviewSetTheme, which the embedded host calls. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] The page applies light and dark themes from the theme query and from assetReviewSetTheme, which the embedded host calls. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveTheme); ./build.ps1 Test)


## TEST-SERVERONLY

### TEST-SERVERONLY-001

--server-only serves the review UI without opening a desktop window and reports the URL and launch mode. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] --server-only serves the review UI without opening a desktop window and reports the URL and launch mode. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveServerOnly); ./build.ps1 Test)


## TEST-TOOLVERSION

### TEST-TOOLVERSION-001

--version prints the asset-review version and exits successfully. Run the corresponding scenario using ./build.ps1 Test.

**Acceptance Criteria:**
- [ ] --version prints the asset-review version and exits successfully. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveVersion); ./build.ps1 Test)
