# Functional Requirements (QBrain.AI)

## FR-ASSETREVIEW-001 PNG and SVG review grid

The review app lists PNG and SVG files from the asset root under the configured title.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The review app lists PNG and SVG files from the asset root under the configured title. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DrivePngAndSvgGrid); ./build.ps1 Test)

## FR-ASSETREVIEW-002 JSONL feedback record

Feedback is appended as JSON Lines recording the asset path, decision, comment, preview context, and a UTC timestamp.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Feedback is appended as JSON Lines recording the asset path, decision, comment, preview context, and a UTC timestamp. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveFeedbackRecord); ./build.ps1 Test)

## FR-ASSETREVIEW-003 C64 palette background

The detail view previews an asset on a selectable C64 palette background.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The detail view previews an asset on a selectable C64 palette background. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveC64Palette); ./build.ps1 Test)

## FR-ASSETREVIEW-004 Zoom and scroll preview

Zoom changes through the slider or Ctrl/Meta+mouse wheel, and a plain wheel scrolls the preview when the image overflows.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Zoom changes through the slider or Ctrl/Meta+mouse wheel, and a plain wheel scrolls the preview when the image overflows. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveZoomAndScroll); ./build.ps1 Test)

## FR-ASSETREVIEW-005 Reload All

Reload All rescans the asset root and shows files added after launch.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Reload All rescans the asset root and shows files added after launch. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveReloadAll); ./build.ps1 Test)

## FR-ASSETREVIEW-006 Clear non-approved reviews

Clear Reviews removes non-approved feedback and keeps the current approved decisions.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Clear Reviews removes non-approved feedback and keeps the current approved decisions. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveClearReviews); ./build.ps1 Test)

## FR-ASSETREVIEW-007 Generate review manifest

--generate-manifest scans the asset root for PNG and SVG files, writes backtick-wrapped relative paths to _manifest.md, and exits.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] --generate-manifest scans the asset root for PNG and SVG files, writes backtick-wrapped relative paths to _manifest.md, and exits. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveGenerateManifest); ./build.ps1 Test)

## FR-ASSETREVIEW-008 Prefer manifest over folder scan

When _manifest.md lists assets, the review index uses that list instead of every image in the folder.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] When _manifest.md lists assets, the review index uses that list instead of every image in the folder. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveManifestPreference); ./build.ps1 Test)

## FR-ASSETREVIEW-009 Search and status filters

Search text and the All, Open, Approved, and Refine filters limit which assets are shown.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Search text and the All, Open, Approved, and Refine filters limit which assets are shown. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveSearchAndFilters); ./build.ps1 Test)

## FR-ASSETREVIEW-010 Approve and request refinement

Approve and Request refinement save a decision and show it on the open asset.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Approve and Request refinement save a decision and show it on the open asset. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveApproveAndRefine); ./build.ps1 Test)

## FR-ASSETREVIEW-011 In-flight storyboard sequences

Hero and monster combat folders expose storyboard sequences that can play in flight, step a frame, and switch sequence.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Hero and monster combat folders expose storyboard sequences that can play in flight, step a frame, and switch sequence. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveStoryboard); ./build.ps1 Test)

## FR-ASSETREVIEW-012 Version command

--version prints the asset-review version and exits successfully.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] --version prints the asset-review version and exits successfully. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveVersion); ./build.ps1 Test)

## FR-ASSETREVIEW-013 Server-only launch

--server-only serves the review UI without opening a desktop window and reports the URL and launch mode.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] --server-only serves the review UI without opening a desktop window and reports the URL and launch mode. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveServerOnly); ./build.ps1 Test)

## FR-ASSETREVIEW-014 Reject path escape

Asset and feedback routes reject paths that escape the asset root.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Asset and feedback routes reject paths that escape the asset root. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DrivePathEscape); ./build.ps1 Test)

## FR-ASSETREVIEW-015 Light and dark theme

The page applies light and dark themes from the theme query and from assetReviewSetTheme, which the embedded host calls.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The page applies light and dark themes from the theme query and from assetReviewSetTheme, which the embedded host calls. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveTheme); ./build.ps1 Test)

## FR-ASSETREVIEW-016 Folder rail

The folder rail filters the grid and shows approval, refinement, and total counts.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The folder rail filters the grid and shows approval, refinement, and total counts. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveFolderRail); ./build.ps1 Test)

## FR-ASSETREVIEW-017 Detail navigation

Next, previous, and back navigation move through the current asset list and return to the grid.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] Next, previous, and back navigation move through the current asset list and return to the grid. (evidence: tests/AssetReview.AiUnit.Tests/Requirements/RequirementDrivers.cs (DriveNavigation); ./build.ps1 Test)

## FR-ASSETREVIEW-018 Labeled storyboard branches and loops in manifests

Manifest authors can describe a storyboard with stable frame IDs, labeled alternate paths, joins, and labeled loops back to earlier frames.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] A storyboard manifest can assign frame IDs and author labeled branches and loops. Loading returns each frame and transition with its original label and explicit target, including shared destinations and repeated references to the same asset.
- [ ] Regenerating a manifest preserves the authored storyboard graph, and legacy ordered storyboards still load with their original frame order.
- [ ] An invalid graph reports the relevant manifest and source line. Rejected graph data and missing frame files do not prevent valid storyboards in the same manifest from loading.

## FR-ASSETREVIEW-019 Display storyboards as PlantUML activity diagrams

The storyboard review UI displays the authored storyboard and its labeled branches and loops as a PlantUML activity diagram.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The storyboard displays a locally rendered PlantUML activity diagram showing each authored frame occurrence, labeled branch, shared destination, and labeled loop.
- [ ] Reviewers can select transitions, revisit prior frames, and attach feedback to the actual frame occurrence while existing linear storyboard behavior remains available.
- [ ] An invalid manifest or unavailable local renderer is explained in the review UI, which remains usable for reviewing available frames.

## FR-ASSETREVIEW-020 Install one AssetReview package on Windows and Linux

Package Windows and Linux AssetReview applications together and select the appropriate application at launch.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The SharpNinja.AssetReview.Tool NuGet package contains a portable asset-review launcher and Windows and Linux application payloads for x64 and ARM64.
- [ ] The launcher selects the payload using the running OS and process architecture, preserves the working directory and arguments, and returns the application exit code.
- [ ] The Nuke packaging target verifies the package layout and target metadata. The same artifact installs and launches the matching payload on both Windows and Linux.

## FR-ASSETREVIEW-021 Simulate a storyboard in the frame previewer

Reviewers can step through the authored storyboard and see the wireframe for each visited frame.
Scope: layer-1+
**Acceptance Criteria:**
- [ ] The simulator displays the actual wireframe in the existing previewer at each visited step and provides navigation icons to move forward, revisit the previous step, or restart.
- [ ] Every outgoing branch is available as a button showing its authored label. Selecting it previews the branch destination.
- [ ] A loop can repeat via its authored label or leave via Break. Break follows an authored Next exit or presents authored branch exits. If there is no exit, the simulation ends on the final wireframe of the loop.

